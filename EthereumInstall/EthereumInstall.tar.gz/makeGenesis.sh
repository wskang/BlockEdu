geth --datadir /home/ethereum/privatechain init /home/ethereum/CustomGenesis.json
